# Tool Dịch File & Lồng Tiếng Video

Web app gồm 2 chức năng:
1. **Dịch file** — txt / docx / pdf, dịch sang ngôn ngữ bất kỳ, giữ nguyên định dạng.
2. **Lồng tiếng video** — dựa trên phụ đề (.srt/.vtt) có sẵn: dịch lời thoại, tạo giọng đọc bằng AI, canh khớp thời gian, ghép vào video.

## Kiến trúc

```
translate-dub-tool/
├── backend/              # FastAPI (Python) — xử lý dịch, TTS, ffmpeg
│   ├── main.py
│   ├── services/
│   │   ├── translator.py         # dịch văn bản qua Claude API
│   │   ├── document_processor.py # đọc/ghi txt, docx, pdf
│   │   ├── tts_service.py        # tạo giọng nói qua ElevenLabs
│   │   └── video_dubber.py       # canh timing + ghép audio vào video
│   ├── requirements.txt
│   └── .env.example
└── frontend/
    └── index.html        # giao diện web, gọi thẳng API backend
```

## Yêu cầu hệ thống

- Python 3.10+
- **ffmpeg** đã cài và có trong PATH (dùng để xử lý audio/video)
  - macOS: `brew install ffmpeg`
  - Ubuntu/Debian: `sudo apt install ffmpeg`
  - Windows: tải tại https://ffmpeg.org/download.html rồi thêm vào PATH
- Tài khoản **Anthropic API** (dịch văn bản): https://console.anthropic.com
- Tài khoản **ElevenLabs** (tạo giọng nói, cần cho phần lồng tiếng video): https://elevenlabs.io

## Cài đặt

```bash
cd backend
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# Mở .env và điền ANTHROPIC_API_KEY, ELEVENLABS_API_KEY
```

## Chạy

**Backend:**
```bash
cd backend
python main.py
# Chạy tại http://localhost:8000
```

**Frontend:**
Chỉ cần mở trực tiếp file `frontend/index.html` bằng trình duyệt
(hoặc dùng `python -m http.server 5500` trong thư mục `frontend/` rồi mở `http://localhost:5500`).

## Cách dùng

### Dịch file
1. Chọn tab "Dịch file"
2. Tải lên file .txt / .docx / .pdf
3. Chọn ngôn ngữ đích
4. Bấm "Dịch file" — file dịch sẽ tự tải xuống

### Lồng tiếng video
1. Chuẩn bị video (mp4...) và file phụ đề .srt/.vtt tương ứng, đúng lời thoại
2. Chọn tab "Lồng tiếng video", tải cả 2 file lên
3. Chọn ngôn ngữ lồng tiếng, (tuỳ chọn) nhập Voice ID của ElevenLabs
4. Bấm "Lồng tiếng video" — quá trình có thể mất vài phút tuỳ độ dài video

**Lưu ý về Voice ID:** Vào https://elevenlabs.io/app/voice-library để chọn giọng
(nam/nữ, ngôn ngữ), copy Voice ID và dán vào ô tương ứng. Nếu để trống sẽ dùng
giọng mặc định "Rachel" (giọng nữ, đa ngôn ngữ).

## Cách hoạt động của phần lồng tiếng (quan trọng để hiểu giới hạn)

- Mỗi dòng phụ đề được dịch riêng rồi tạo audio riêng.
- Audio mỗi dòng được co giãn tốc độ (`ffmpeg atempo`) để vừa khít khoảng thời gian
  của dòng phụ đề gốc — do đó nếu bản dịch dài hơn nhiều so với bản gốc, giọng đọc
  ra có thể hơi nhanh (tool giới hạn co giãn trong khoảng 0.5x–2x để giọng không bị méo quá).
- Track audio lồng tiếng sẽ **thay thế hoàn toàn** track audio gốc của video
  (không giữ nhạc nền/hiệu ứng gốc). Nếu cần giữ nhạc nền, cần tách riêng lời thoại
  và nhạc nền trước (có thể bổ sung bằng công cụ tách audio như Demucs/Spleeter).

## Deploy lên internet (để ai cũng truy cập được)

Backend và frontend deploy **riêng biệt**, ở 2 nơi khác nhau.

### Bước 1 — Đưa code lên GitHub (bắt buộc, vì Render/Vercel deploy từ GitHub repo)

```bash
cd translate-dub-tool
git init
git add .
git commit -m "First commit"
```
Vào https://github.com/new tạo repo mới (đặt tên tuỳ ý, để Public hoặc Private đều được),
rồi làm theo hướng dẫn GitHub đưa ra để push code lên (đại loại):
```bash
git remote add origin https://github.com/ten-ban/ten-repo.git
git branch -M main
git push -u origin main
```

### Bước 2 — Deploy backend lên Render.com

1. Vào https://render.com, đăng ký/đăng nhập bằng GitHub
2. Chọn **New +** → **Web Service** → chọn đúng repo GitHub vừa push
3. Render tự phát hiện `Dockerfile` trong thư mục `backend/` — chọn:
   - **Root Directory**: `backend`
   - **Runtime**: Docker
4. Vào tab **Environment**, thêm các biến môi trường (giống file `.env`):
   - `ANTHROPIC_API_KEY`
   - `ELEVENLABS_API_KEY`
5. Bấm **Create Web Service**. Đợi build xong, Render sẽ cho bạn 1 URL dạng
   `https://ten-app.onrender.com` — đó là địa chỉ backend thật.

> Lưu ý: gói miễn phí của Render sẽ "ngủ" sau ~15 phút không dùng, lần gọi đầu
> sau đó sẽ chậm (khoảng 30-60s để "thức dậy"). Nếu cần chạy ổn định, cân nhắc
> gói trả phí (~7$/tháng).

### Bước 3 — Deploy frontend lên Vercel (hoặc Netlify)

1. Mở file `frontend/index.html`, sửa dòng `API_BASE` thành URL backend ở Bước 2:
   ```js
   const API_BASE = "https://ten-app.onrender.com";
   ```
   Commit và push lại lên GitHub.
2. Vào https://vercel.com, đăng nhập bằng GitHub → **Add New** → **Project**
3. Chọn repo, đặt **Root Directory** là `frontend`
4. Vì đây chỉ là HTML tĩnh, không cần build command gì — bấm **Deploy**
5. Vercel cho bạn 1 link dạng `https://ten-web.vercel.app` — đây là link chia sẻ được cho mọi người.

### Bước 4 — Cập nhật CORS ở backend

Vào lại Render → sửa trong `backend/main.py` phần `allow_origins`, thay `["*"]`
bằng đúng domain Vercel ở Bước 3 (bảo mật hơn), rồi commit + push để Render tự deploy lại.

## Có thể mở rộng thêm

- Thêm provider TTS khác (Google Cloud TTS, Azure, OpenAI TTS) trong `tts_service.py`
- Tự động tạo transcript bằng Whisper nếu video chưa có phụ đề sẵn
- Giữ nhạc nền gốc bằng cách tách audio (vocal/instrumental) trước khi lồng tiếng
- Deploy backend lên server thật (Render, Railway, VPS...) và host frontend tĩnh
